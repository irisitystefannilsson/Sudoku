function []= sat_done()
sat(2);

