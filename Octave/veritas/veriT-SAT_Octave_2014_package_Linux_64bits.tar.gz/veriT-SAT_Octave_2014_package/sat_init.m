function []= sat_init()
sat(0);


